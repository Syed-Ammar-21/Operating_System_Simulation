#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
    // Seed the random number generator
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    int lowerLimit = 1;
    int upperLimit = 5;
    int targetNumber = std::rand() % (upperLimit - lowerLimit + 1) + lowerLimit;

    int guess;
    int attempts = 0;
    const int maxAttempts = 5;

    std::cout << "Welcome to the Number Guessing Game!" << std::endl;
    std::cout << "I have selected a number between " << lowerLimit << " and " << upperLimit << ". Try to guess it!" << std::endl;

    do {
        // Get the user's guess
        std::cout << "Enter your guess (Attempt " << attempts + 1 << " of " << maxAttempts << "): ";
        std::cin >> guess;

        // Increment the number of attempts
        attempts++;

        if (guess < targetNumber) {
            std::cout << "Your guess is too low. Try again!" << std::endl;
        } else if (guess > targetNumber) {
            std::cout << "Your guess is too high. Try again!" << std::endl;
        } else {
            std::cout << "Congratulations! You've guessed the number in " << attempts << " attempts." << std::endl;
            break;
        }

        // If user has used up all attempts
        if (attempts == maxAttempts) {
            std::cout << "Sorry! You've used all your attempts. The correct number was " << targetNumber << "." << std::endl;
            break;
        }

    } while (guess != targetNumber);  // Repeat until the user guesses correctly or exceeds max attempts

    return 0;  // Exit successfully
}
