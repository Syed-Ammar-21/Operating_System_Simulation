#include <iostream>
#include <iomanip>
using namespace std;

void displayCalendar(int year, int month) {
    // Calculate the total number of days in the month
    int daysInMonth;
    if (month == 2) {
        // Check for leap year
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            daysInMonth = 29;
        } else {
            daysInMonth = 28;
        }
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
        daysInMonth = 30;
    } else {
        daysInMonth = 31;
    }

    // Calculate the weekday of the first day of the month (Zeller's Congruence)
    int q = 1;  // Day of the month
    int m = month < 3 ? month + 12 : month;
    int K = (month < 3) ? (year - 1) % 100 : year % 100;
    int J = (month < 3) ? (year - 1) / 100 : year / 100;
    int h = (q + 13 * (m + 1) / 5 + K + K / 4 + J / 4 + 5 * J) % 7;
    int dayOfWeek = (h + 6) % 7;  // Adjust to make Sunday=0

    // Print the calendar header
    cout << "-----------------------------" << endl;
    cout << "         " << setw(4) << year << " / " << setw(2) << month << endl;
    cout << "-----------------------------" << endl;
    cout << " Sun Mon Tue Wed Thu Fri Sat" << endl;

    // Print the calendar body
    int day = 1;
    for (int row = 0; row < 6; row++) {
        for (int col = 0; col < 7; col++) {
            if ((row == 0 && col < dayOfWeek) || day > daysInMonth) {
                cout << setw(4) << " ";
            } else {
                cout << setw(4) << day;
                day++;
            }
        }
        cout << endl;
        if (day > daysInMonth) {
            break;
        }
    }
    cout << "-----------------------------" << endl;
}

int main() {
    while (true) {
        int year, month;
        cout << "\nEnter the year (or 0 to exit): ";
        cin >> year;
        if (year == 0) {
            break;
        }
        cout << "Enter the month (1-12): ";
        cin >> month;
        if (month < 1 || month > 12) {
            cout << "Invalid month. Please enter a value from 1 to 12.\n";
            continue;
        }

        displayCalendar(year, month);
    }

    cout << "\nExiting Calendar Program. Goodbye!\n";
    return 0;
}


