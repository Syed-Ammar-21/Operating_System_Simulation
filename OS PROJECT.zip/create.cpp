#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    string fileName;
    string extention;
    int choice;

    cout << "Enter File Name: ";
    cin >> fileName;

    // Select file extension (either .txt or .dat)
    do {
        cout << "Select extension " << endl
             << "1. Text (.txt)" << endl
             << "2. Data (.dat)" << endl
             << "choice: ";
        cin >> choice;
        if (choice == 1) {
            extention = ".txt";
        }
        else if (choice == 2) {
            extention = ".dat";
        }
        else {
            cout << "Wrong Extension" << endl;
        }
    } while (choice < 1 || choice > 2);

    fileName = fileName + extention;

    // Create the file if it doesn't exist
    ofstream file(fileName, ios::app); // Open in append mode
    if (!file) {
        cout << "Error: Could not create or open the file." << endl;
        return 1;
    } else {
        cout << "File created successfully!" << endl;
    }

    // Give the user an option to write or exit
    char writeChoice;
    cout << "Do you want to write to the file? (y/n): ";
    cin >> writeChoice;

    if (writeChoice == 'y' || writeChoice == 'Y') {
        // Ask the user for input to write to the file
        string text;
        cout << "Enter text to write to the file: ";
        cin.ignore(); // To clear the newline character left by previous input
        getline(cin, text);  // Get the whole line of text

        // Write the text to the file
        file << text << endl;
        cout << "Text written to the file successfully!" << endl;
    } else {
        cout << "No text written. Exiting program." << endl;
    }

    // Close the file
    file.close();

    return 0;
}
