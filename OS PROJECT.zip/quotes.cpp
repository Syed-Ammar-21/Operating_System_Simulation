#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
    // Array of quotes
    const char* quotes[] = {
        "Be yourself; everyone else is already taken. - Oscar Wilde",
        "Two things are infinite: the universe and human stupidity; and I'm not sure about the universe. - Albert Einstein",
        "In the end, it's not the years in your life that count. It's the life in your years. - Abraham Lincoln",
        "The only way to do great work is to love what you do. - Steve Jobs",
        "Believe you can and you're halfway there. - Theodore Roosevelt",
        "You miss 100% of the shots you don't take. - Wayne Gretzky",
        "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
        "What lies behind us and what lies before us are tiny matters compared to what lies within us. - Ralph Waldo Emerson",
        "It does not matter how slowly you go as long as you do not stop. - Confucius",
        "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment. - Ralph Waldo Emerson"
    };

    // Get the number of quotes
    const int numQuotes = sizeof(quotes) / sizeof(quotes[0]);

    // Seed the random number generator
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    char choice;
    do {
        // Generate a random index
        int randomIndex = std::rand() % numQuotes;

        // Print the random quote
        std::cout << "\nRandom Quote of the Day:\n";
        std::cout << quotes[randomIndex] << std::endl;

        // Ask the user if they want another quote or to exit
        std::cout << "\nDo you want another quote? (y/n): ";
        std::cin >> choice;

        // Validate input
        while(choice != 'y' && choice != 'n') {
            std::cout << "Invalid choice. Please enter 'y' for yes or 'n' for no: ";
            std::cin >> choice;
        }

    } while(choice == 'y');  // Repeat if the user wants another quote

    std::cout << "\nThank you for using the Quotes app. Goodbye!" << std::endl;

    return 0;  // Exit successfully
}
