#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    string sourceFileName, destinationFileName;
    
    // Ask the user for the source file name (the file to copy from)
    cout << "Enter the source file name (including extension): ";
    cin >> sourceFileName;

    // Ask the user for the destination file name (the file to copy to)
    cout << "Enter the destination file name (including extension): ";
    cin >> destinationFileName;

    // Open the source file for reading
    ifstream sourceFile(sourceFileName);
    if (!sourceFile) {
        cout << "Error: Source file not found or could not be opened!" << endl;
        return 1;
    }

    // Open the destination file for writing
    ofstream destinationFile(destinationFileName);
    if (!destinationFile) {
        cout << "Error: Could not open destination file for writing!" << endl;
        return 1;
    }

    // Copy the contents from source to destination
    string line;
    while (getline(sourceFile, line)) {
        destinationFile << line << endl;  // Write the line to the destination file
    }

    // Close both files
    sourceFile.close();
    destinationFile.close();

    cout << "File copied successfully!" << endl;

    return 0;
}

