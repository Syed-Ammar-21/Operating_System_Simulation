#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int main()
{
    string fileName;
    string extention;
    int choice;

    cout << "Enter File Name: ";
    cin >> fileName;

    // Choose file extension
    do {
        cout << "Select extension " << endl
             << "1. Text (.txt)" << endl
             << "2. Data (.dat)" << endl
             << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            extention = ".txt";
        }
        else if (choice == 2) {
            extention = ".dat";
        }
        else {
            cout << "Wrong Extension" << endl;
        }
    } while (choice < 1 || choice > 2);

    fileName = fileName + extention;

    // Check if file exists
    ifstream temp;
    temp.open(fileName);

    if (temp.fail()) {
        cout << "No file of this name exists" << endl;
    }
    else {
        // File exists, delete it
        if (remove(fileName.c_str()) == 0) {
            cout << "File Deleted Successfully" << endl;
        }
        else {
            cout << "Failed to delete the file" << endl;
        }
    return 0;
}
}
