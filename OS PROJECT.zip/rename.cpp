#include<iostream>
#include<fstream>
#include<string>
#include<unistd.h>  // For the rename function
using namespace std;

int main() {
    string oldFileName, newFileName;
    string extention;
    int choice;

    cout << "Enter the current File Name to rename: ";
    cin >> oldFileName;

    // Choose file extension
    do {
        cout << "Select extension " << endl
             << "1. Text (.txt)" << endl
             << "2. Data (.dat)" << endl
             << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            extention = ".txt";
        }
        else if (choice == 2) {
            extention = ".dat";
        }
        else {
            cout << "Wrong Extension" << endl;
        }
    } while (choice < 1 || choice > 2);

    oldFileName = oldFileName + extention;

    // Check if file exists
    ifstream temp;
    temp.open(oldFileName);

    if (temp.fail()) {
        cout << "No file of this name exists" << endl;
    }
    else {
        // Ask for new file name
        cout << "Enter the new file name: ";
        cin >> newFileName;
        newFileName = newFileName + extention;

        // Rename the file
        if (rename(oldFileName.c_str(), newFileName.c_str()) == 0) {
            cout << "File Renamed Successfully to " << newFileName << endl;
        }
        else {
            cout << "Failed to rename the file" << endl;
        }
    }

    // Wait for user input to exit
    cin.ignore();
    cout << "\t\t\t" << "Press any key to Exit..." << endl;
    cin.get();

    return 0;
}
