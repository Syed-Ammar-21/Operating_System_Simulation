#include <iostream>
#include <unistd.h>
#include <string>
#include <chrono>
#include <thread>
using namespace std;

void welcome() {
    // Welcome message and loading animation
    cout << "Welcome to Astro Calculator!\n";
    cout << "Loading...";
    string animation = "|/-\\";
    system("clear");
    for (int i = 0; i < 20; i++) {
        cout << animation[i % 4] << flush;
        this_thread::sleep_for(chrono::milliseconds(100));
    }
    cout << "\n";
}

int main() {
    welcome();
    bool exitFlag = false;
    while (!exitFlag) {
        // Display menu options
        cout << "Please select an operation:\n";
        cout << "1. Addition (+)\n";
        cout << "2. Subtraction (-)\n";
        cout << "3. Multiplication (*)\n";
        cout << "4. Division (/)\n";
        cout << "5. Exit\n";
        cout << "Enter your choice (1-5): ";

        int choice;
        cin >> choice;

        switch (choice) {
            case 1: {
                float num1, num2;
                cout << "Enter two numbers to add:\n";
                cin >> num1 >> num2;
                cout << "Result: " << num1 + num2 << "\n\n";
                break;
            }
            case 2: {
                float num1, num2;
                cout << "Enter two numbers to subtract:\n";
                cin >> num1 >> num2;
                cout << "Result: " << num1 - num2 << "\n\n";
                break;
            }
            case 3: {
                float num1, num2;
                cout << "Enter two numbers to multiply:\n";
                cin >> num1 >> num2;
                cout << "Result: " << num1 * num2 << "\n\n";
                break;
            }
            case 4: {
                float num1, num2;
                cout << "Enter two numbers to divide:\n";
                cin >> num1 >> num2;
                if (num2 == 0) {
                    cout << "Error: division by zero.\n\n";
                } else {
                    cout << "Result: " << num1 / num2 << "\n\n";
                }
                break;
            }
            case 5:
                cout << "Exiting Calculator...\n";
                exitFlag = true;
                break;
            default:
                cout << "Invalid choice. Please enter a number from 1 to 5.\n\n";
                break;
        }
    }

    return 0;
}

