#include <iostream>
#include <fstream>
#include <string>

int main() {
    std::string filename = "note.txt";
    std::ifstream file(filename);

    if (file) {
        std::cout << "File contents:\n";
        std::string line;
        while (std::getline(file, line)) {
            std::cout << line << '\n';
        }
        file.close();
    } else {
        std::cout << "File not found! A new file will be created.\n";
    }

    std::cout << "\nEnter text to append to the file (type 'q' and press Enter to quit):\n";

    std::string text;
    while (true) {
        std::getline(std::cin, text);

        if (text == "q") {
            std::cout << "Exiting...\n";
            break;
        }

        std::ofstream outfile(filename, std::ios_base::app);
        if (outfile) {
            outfile << text << '\n';
            outfile.close();
        } else {
            std::cerr << "Error opening file for writing.\n";
        }
    }

    return 0;
}
