#include <iostream>
#include <cstdlib>
using namespace std;

// Function to print the game board
void printboard(int board[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == 0)
                cout << "_ ";
            else if (board[i][j] == 1)
                cout << "X ";
            else
                cout << "O ";
        }
        cout << endl;
    }
}

// Function to check if a player has won
bool checkwinner(int board[3][3], int& who) {
    // Check rows, columns, and diagonals for a winner
    for (int i = 0; i < 3; i++) {
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != 0) {
            who = board[i][0];
            return true;
        }
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != 0) {
            who = board[0][i];
            return true;
        }
    }

    // Check diagonals
    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != 0) {
        who = board[0][0];
        return true;
    }
    if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != 0) {
        who = board[0][2];
        return true;
    }

    return false;
}

// Function to get the player's move
bool getPlayerMove(int board[3][3], int player, int& row, int& col) {
    cout << "Player " << (player == 1 ? "X" : "O") << ", enter your move (row and column): ";
    cin >> row >> col;

    // Check if the entered row and column are within bounds and the cell is empty
    if (row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == 0) {
        return true;  // Valid move
    } else {
        cout << "Invalid move, try again." << endl;
        return false;  // Invalid move
    }
}

int main() {
    int board[3][3] = {0};  // Initialize the board with zeros (empty cells)
    int player = 1;  // Player 1 starts (X)
    int row, col, winner = 0;  // To store row, column, and the winner

    // Start the game loop
    for (int turn = 0; turn < 9; turn++) {
        printboard(board);  // Print the board

        // Get the current player's move
        while (!getPlayerMove(board, player, row, col)) {
            // Keep asking for input until a valid move is made
        }

        // Place the player's mark on the board
        board[row][col] = player;

        // Check if the current player has won
        if (checkwinner(board, winner)) {
            printboard(board);  // Print the final board
            cout << "Player " << (winner == 1 ? "X" : "O") << " wins!" << endl;
            break;
        }

        // Switch player
        player = (player == 1) ? 2 : 1;
    }

    // If all turns are used and no winner, it's a draw
    if (winner == 0) {
        printboard(board);
        cout << "It's a draw!" << endl;
    }

    return 0;
}
