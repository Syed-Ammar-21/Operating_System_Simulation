#include <iostream>
#include <chrono>
#include <thread>
#include <iomanip>
using namespace std;

void displayTime() {
    // Get the current system time
    auto now = chrono::system_clock::now();
    time_t currentTime = chrono::system_clock::to_time_t(now);

    // Format the current time to a readable string
    struct tm* localTime = localtime(&currentTime);
    cout << put_time(localTime, "%Y-%m-%d %H:%M:%S") << endl;
}

int main() {
    while (true) {
        system("clear");  // Clears the screen (optional for clean output)

        // Display the current time
        cout << "Current Time: ";
        displayTime();

        cout << "\nPress '0' to exit, or any other key to refresh the clock...\n";

        // Wait for 1 second before updating the time
        this_thread::sleep_for(chrono::seconds(1));

        char userInput;
        cin >> userInput;

        if (userInput == '0' || userInput == 'e') {  // Exit when '0' or 'exit' typed
            break;
        }
    }

    cout << "\nExiting Clock Program. Goodbye!\n";
    return 0;
}
